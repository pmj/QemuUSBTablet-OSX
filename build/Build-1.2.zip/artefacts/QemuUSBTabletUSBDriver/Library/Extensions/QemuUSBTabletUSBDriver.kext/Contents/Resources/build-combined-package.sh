#!/bin/sh
productbuild --distribution Distribution.xml --package-path ./ --resources Resources/ --sign "Developer ID Installer: Phillip Jordan" QemuUSBTablet-1.2.pkg
